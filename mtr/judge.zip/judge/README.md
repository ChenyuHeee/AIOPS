# AIOps Submission Evaluator

This folder ships a lightweight offline evaluator that follows the component / reason / reasoning-trace rubric described in `评测程序编写思路.md`.

## Expected Data Format

Both the ground-truth file and the submission file must use JSON Lines (`.jsonl`). Each line describes one task and must contain the following fields:

```
{
  "uuid": "33c11d00-2",
  "component": "checkoutservice",
  "reason": "disk IO overload",
  "reasoning_trace": [
    {"step": 1, "action": "QueryMetric", "observation": "disk_read_latency spike"}
  ]
}
```

The ground-truth file can optionally include:

- `reason_keywords`: keyword list used for fast reason matching before semantic similarity checks.
- `evidence_points`: array of `{ "type": "metric|log|trace", "keywords": ["keyword"] }` blocks that describe the key evidence items that should surface in `reasoning_trace[].observation`.

## Running the Evaluator

```
/Users/hechenyu/projects/AIOPS/.venv/bin/python mtr/judge/evaluate.py \
  --ground-truth mtr/judge/samples/ground_truth.jsonl \
  --submission mtr/judge/samples/submission.jsonl \
  --show-details
```

### Arguments

- `--ground-truth/-g`: path to the reference JSONL file.
- `--submission/-s`: path to the output JSONL produced by the model/agent.
- `--reason-threshold`: optional similarity threshold (0-1). Defaults to `0.65`.
- `--show-details`: prints a CSV-style per-sample summary for quick inspection.
- `--report/-o`: saves the full metrics + per-sample breakdown in JSON format.

## Sample Data

`mtr/judge/samples/` contains a tiny two-task dataset that mirrors the scoring logic described in the design document. It is useful for sanity checks:

```
/Users/hechenyu/projects/AIOPS/.venv/bin/python mtr/judge/evaluate.py \
  -g mtr/judge/samples/ground_truth.jsonl \
  -s mtr/judge/samples/submission.jsonl \
  --show-details
```

This should reproduce the console output demonstrated during development.
